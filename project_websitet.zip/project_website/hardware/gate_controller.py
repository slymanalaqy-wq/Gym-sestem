import requests
import time
import winsound  # المكتبة المسؤولة عن أصوات النظام في ويندوز

# === الإعدادات ===
API_URL = 'http://localhost:8081/project_website/backend/api/biometric.php'

# === محاكاة قراءة البصمة ===
def read_fingerprint():
    """
    هنا يتم استبدال القيمة يدوياً لاختبار حالات مختلفة:
    1. بصمة صحيحة مسجلة.
    2. بصمة غير موجودة.
    """
    print("\n" + "-"*30)
    fp = input("🔹 ضع رقم البصمة للاختبار (أو اضغط Enter للقيمة الافتراضية FP12345): ")
    return fp if fp else "FP12345"

# === فتح البوابة (محاكاة) ===
def open_gate():
    print("🔓 [ACTION] جاري فتح البوابة إلكترونياً...")
    # هنا مستقبلاً ترسل إشارة للـ Relay
    time.sleep(1)
    print("✅ [GATE] البوابة مفتوحة الآن.")
    time.sleep(3)
    print("🔒 [GATE] تم إغلاق البوابة.")

# === النظام الرئيسي ===
def main():
    print("=" * 50)
    print("🚀 نظام الدخول الذكي للنادي الرياضي يعمل الآن...")
    print("=" * 50)
    
    while True: # حلقة تكرار ليبقى البرنامج شغالاً دائماً
        try:
            # 1. قراءة البصمة
            fp_id = read_fingerprint()
            
            # 2. إرسال الطلب إلى السيرفر
            print(f"📡 فحص الصلاحية عبر السيرفر...")
            response = requests.post(
                API_URL,
                data={'fingerprint_id': fp_id},
                timeout=5
            )
            
            if response.status_code == 200:
                result = response.json()
                
                # 3. تحليل النتيجة واتخاذ إجراء
                if result.get('success'):
                    # حالة النجاح
                    print(f"🟢 تم السماح بالدخول: {result.get('name')}")
                    print(f"💬 رسالة السيرفر: {result.get('message')}")
                    
                    # صوت رنة نجاح (تردد 1000 هيرتز لمدة نصف ثانية)
                    winsound.Beep(1000, 500) 
                    
                    open_gate()
                else:
                    # حالة الرفض (اشتراك منتهي أو بصمة خطأ)
                    print(f"🔴 دخول مرفوض: {result.get('message')}")
                    
                    # صوت تنبيه خطأ (تردد 400 هيرتز لمدة ثانية كاملة)
                    winsound.Beep(400, 1000) 
                    
            else:
                print(f"❌ خطأ في السيرفر: {response.status_code}")
                
        except requests.exceptions.ConnectionError:
            print("⚠️ خطأ: فشل الاتصال بالسيرفر. تأكد أن XAMPP يعمل.")
            time.sleep(5) # انتظر قليلاً قبل المحاولة مرة أخرى
        except Exception as e:
            print(f"⚠️ خطأ غير متوقع: {e}")
            break # اخرج من الحلقة في حال وجود خطأ برمجي

if __name__ == "__main__":
    main()