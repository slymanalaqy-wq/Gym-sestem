<?php
$dsn="mysql:host=localhost;dbname=g1;charset=utf8mb4";
$user="root";
$pass="";
try{
$db=new PDO($dsn,$user,$pass);
echo "connect";
}
catch(PDOException $e){
 echo "faild". $e->getMessage(); 
}








?>