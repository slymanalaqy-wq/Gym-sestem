<script src="../js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/datatables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('table').DataTable({
                "language": {
                    "sProcessing": "جاري المعالجة...",
                    "sLengthMenu": "أظهر _MENU_ مدخلات",
                    "sZeroRecords": "لا توجد نتائج",
                    "sInfo": "عرض _START_ إلى _END_ من _TOTAL_ مدخلات",
                    "sSearch": "بحث:",
                    "oPaginate": {
                        "sFirst": "الأول",
                        "sPrevious": "السابق",
                        "sNext": "التالي",
                        "sLast": "الأخير"
                    }
                }
            });
        });
    </script>
</body>
</html>








