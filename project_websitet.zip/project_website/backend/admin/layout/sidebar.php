
<div class="sidebar">
    <div class="p-3"><h5>لوحة التحكم</h5></div>
    <a href="dashboard.php">الرئيسية</a>
    <a href="subscribers.php">المشتركون</a>
    <a href="payments.php">المدفوعات</a>
    <a href="reports.php">التقارير</a>
    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <a href="staff.php">الموظفون</a>
    <?php endif; ?>
    <a href="logout.php" style="position:absolute; bottom:20px;">تسجيل الخروج</a>
</div>
