<?php if (!isset($page_title)) $page_title = 'لوحة التحكم'; ?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?> - النادي الرياضي</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/datatables.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .sidebar { position: fixed; width: 250px; height: 100vh; background: #343a40; color: white; }
        .sidebar a { color: white; padding: 12px 20px; text-decoration: none; display: block; }
        .sidebar a:hover { background: #495057; }
        .content { margin-right: 250px; padding: 20px; }
    </style>
</head>
<body>

<?php if (isset($_GET['message'])): ?>
    <div class="alert alert-success alert-dismissible fade show" style="position:fixed; top:20px; right:20px; z-index:1000;">
        <?php
        $msgs = [
            'added' => 'تمت الإضافة بنجاح!',
            'updated' => 'تم التحديث بنجاح!',
            'deleted' => 'تم الحذف بنجاح!',
            'renewed' => 'تم تجديد الاشتراك!'
        ];
        echo $msgs[$_GET['message']] ?? 'تمت العملية بنجاح!';
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
<?php endif; ?>


